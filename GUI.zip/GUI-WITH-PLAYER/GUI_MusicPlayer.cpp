#include "raylib.h"
#define RAYGUI_IMPLEMENTATION
#include "raygui.h"
#include <iostream>
#include <cstring>
#include <vector>
#include <fstream>
#include <algorithm>

#define Clamp(value, min, max) ((value < min) ? min : (value > max) ? max : value)

using namespace std;

class MusicPlayer {
private:
    vector<string> playlist;
    int currentIndex = -1;
    Music music;
    bool isPlaying = false;
    bool isLoaded = false;
    float volume = 1.0f;

public:
    MusicPlayer() {
        LoadPlaylist();
    }

    ~MusicPlayer() {
        Stop();
    }

    void Load(const string& filename) {
        if (isPlaying || isLoaded) Stop();
        music = LoadMusicStream(filename.c_str());
        if (music.ctxData != nullptr) {
            isLoaded = true;
            Play();
        }
    }

    void Play() {
        if (isLoaded) {
            PlayMusicStream(music);
            isPlaying = true;
        }
    }

    void Pause() {
        if (isLoaded && isPlaying) {
            PauseMusicStream(music);
            isPlaying = false;
        }
    }

    void Resume() {
        if (isLoaded && !isPlaying) {
            ResumeMusicStream(music);
            isPlaying = true;
        }
    }

    void Stop() {
        if (isLoaded) {
            StopMusicStream(music);
            UnloadMusicStream(music);
            isPlaying = false;
            isLoaded = false;
        }
    }

    void Update() {
        if (isLoaded) {
            UpdateMusicStream(music);
        }
    }

    void SetVolume(float v) {
        volume = Clamp(v, 0.0f, 1.0f);
        SetMusicVolume(music, volume);
    }

    float GetVolume() const {
        return volume;
    }

    float GetTimePlayed() {
        return GetMusicTimePlayed(music);
    }

    float GetDuration() {
        return GetMusicTimeLength(music);
    }

    void AddToPlaylist(const string& file) {
        playlist.push_back(file);
    }

    void LoadPlaylist() {
        ifstream file("MUSICFILE.txt");
        string line;
        while (getline(file, line)) {
            if (!line.empty()) {
                playlist.push_back(line);
            }
        }
    }

    void SavePlaylist() {
        ofstream file("MUSICFILE.txt");
        for (const auto& song : playlist) {
            file << song << endl;
        }
    }

    void Next() {
        if (playlist.empty()) return;
        currentIndex = (currentIndex + 1) % playlist.size();
        Load(playlist[currentIndex]);
    }

    void Prev() {
        if (playlist.empty()) return;
        currentIndex = (currentIndex - 1 + playlist.size()) % playlist.size();
        Load(playlist[currentIndex]);
    }

    string GetCurrentSong() {
        if (currentIndex >= 0 && currentIndex < playlist.size())
            return playlist[currentIndex];
        return "No song";
    }

    bool IsPlaying() const { return isPlaying; }
    bool IsLoaded() const { return isLoaded; }

    vector<string>& GetPlaylist() {
        return playlist;
    }
};

void DrawSpotifyInterface(MusicPlayer& player, Rectangle playBtn, Rectangle pauseBtn, Rectangle nextBtn, Rectangle prevBtn, Rectangle volumeSlider, Rectangle timelineSlider, Rectangle playlistPanel) {
    ClearBackground(BLACK);

    // Sidebar Panel for Navigation (Left)
    GuiPanel((Rectangle){0, 0, 200, 400}, "Navigation");
    GuiButton((Rectangle){20, 40, 160, 30}, "Home");
    GuiButton((Rectangle){20, 80, 160, 30}, "Library");
    GuiButton((Rectangle){20, 120, 160, 30}, "Playlists");

    // Main Content Area (Right)
    // Album Art and Song Info
    DrawText("Music Player", 220, 20, 30, GREEN);
    DrawText(TextFormat("Now Playing: %s", player.GetCurrentSong().c_str()), 220, 60, 20, LIGHTGRAY);
    
    // Placeholder for Album Art
    DrawCircle(380, 140, 60, DARKGRAY);  // Placeholder circle for album art
    DrawText("Album", 370, 180, 10, WHITE); // Placeholder text for album name

    // Playback Controls (Play, Pause, Next, Previous)
    GuiButton(prevBtn, "Previous");
    GuiButton(playBtn, player.IsPlaying() ? "Pause" : "Play");
    GuiButton(nextBtn, "Next");

    // Volume Control (Slider)
    float volValue = player.GetVolume();
    GuiSliderBar(volumeSlider, "Volume", NULL, &volValue, 0.0f, 1.0f);
    player.SetVolume(volValue);

    // Timeline Control (Slider)
    float currentTime = player.GetTimePlayed();
    float totalTime = player.GetDuration();
    if (totalTime > 0.0f) {
        float timeValue = currentTime / totalTime;
        GuiSliderBar(timelineSlider, "Timeline", NULL, &timeValue, 0.0f, 1.0f);
    }

    // Playlist Panel: Scrollable Playlist
    GuiPanel(playlistPanel, "Playlist");
    const vector<string>& playlist = player.GetPlaylist(); // Get the playlist using the getter method
    int numSongs = playlist.size();
    int maxVisibleSongs = 10;
    int visibleSongs = (numSongs > maxVisibleSongs) ? maxVisibleSongs : numSongs;

    // Display Playlist Buttons
    for (int i = 0; i < visibleSongs; ++i) {
        Rectangle songItemRect = {playlistPanel.x + 10, playlistPanel.y + 30 + i * 30, playlistPanel.width - 20, 25};
        if (GuiButton(songItemRect, playlist[i].c_str())) {
            player.Load(playlist[i]);
        }
    }

    // Scrollbar if there are more songs than fit in the visible area
    if (numSongs > maxVisibleSongs) {
        static int scrollY = 0; // Scroll position
        int scrollMax = numSongs - maxVisibleSongs; // Maximum scroll value
        scrollY = GuiScrollBar((Rectangle){playlistPanel.x + 180, playlistPanel.y + 30, 10, playlistPanel.height - 40}, scrollY, 0, scrollMax);
    }
}

int main() {
    const int screenWidth = 800;
    const int screenHeight = 400;

    InitWindow(screenWidth, screenHeight, "Music Player");
    InitAudioDevice();
    SetTargetFPS(60);

    MusicPlayer player;
    player.Load("example_song.mp3");

    Rectangle playBtn = { 300, 300, 80, 30 };
    Rectangle pauseBtn = { 390, 300, 80, 30 };
    Rectangle nextBtn = { 480, 300, 80, 30 };
    Rectangle prevBtn = { 210, 300, 80, 30 };
    Rectangle volumeSlider = { 600, 60, 150, 20 };
    Rectangle timelineSlider = { 20, screenHeight - 40, 760, 20 };  // Moved timeline slider to the bottom
    Rectangle playlistPanel = { 20, 120, 200, 280 };  // Sidebar panel for the playlist

    while (!WindowShouldClose()) {
        player.Update();

        if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
            Vector2 mouse = GetMousePosition();
            if (CheckCollisionPointRec(mouse, playBtn)) {
                if (player.IsPlaying()) player.Pause();
                else player.Resume();
            }
            if (CheckCollisionPointRec(mouse, nextBtn)) {
                player.Next();
            }
            if (CheckCollisionPointRec(mouse, prevBtn)) {
                player.Prev();
            }
        }

        BeginDrawing();
        DrawSpotifyInterface(player, playBtn, pauseBtn, nextBtn, prevBtn, volumeSlider, timelineSlider, playlistPanel);
        EndDrawing();
    }

    player.SavePlaylist();
    CloseAudioDevice();
    CloseWindow();

    return 0;
}
