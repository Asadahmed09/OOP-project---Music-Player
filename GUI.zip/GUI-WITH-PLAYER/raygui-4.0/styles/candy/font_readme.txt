
V5 Easter Gothic
----------------
Instructions:


++ Easter Gothic ++

For screen use, set at 15pt or any multiple
of 15 (display).  Turn antialiasing off.  Set 
tracking to 100 for best results.

---------------
Usage:  This is a free font--you may use 
this and other V5 fonts at will.  It may not 
be sold, altered, or improperly credited,
however.  All I ask is that you kindly inform 
me if you find this font useful, and where
you've used it.

Enjoy,

�2000 
Roberto Christen
rob@vfive.com


