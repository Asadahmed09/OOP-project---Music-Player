_______________________________
Homespun  Created by Brian Kent
�������������������������������
Thanks for Downloading Homespun.

Homespun TT         [.ttf]
Homespun     [8pt]  [.fon]


  'homespun.fon' is a Windows Bitmap Font (.fon).  This font is best
used at 8pt.  To use it at larger point sizes (for images), try using
a graphics program like Photoshop, Paint Shop Pro, or the Paint
program that comes with Windows.  Type out your text at the recommended
point size [8pt], then resize the image.   Set the color mode to 256
or 2 colors so the edges don't get blured when resizing, then after you
have the text to the size that you want, then change back to a higher
color mode and edit the image.

  For programs that don't show Bitmap Fonts in the Font Selector, you
may be able to get the font to work by typing in:
homespun brk

  When using the TTF version, try using it with anti-aliasing off.


If you have any questions or comments, you can e-mail me at
kentpw@norwich.net

You can visit my Webpage <�NIGMA GAMES & FONTS> at
http://www.aenigmafonts.com/

________________
INSTALLING FONTS
����������������
  There's a couple of ways to install Fonts. The 'easy' way to
install fonts is to just Unzip/place the font file [.ttf] into your
Windows\Fonts directory (I always use this method). If you're unable
to do it the 'easy' way, then try to do it this way (for Windows
95/98/NT):

1] Unzip the Font(s) to a folder (or somewhere, just remember where
you unzipped it) on your Computer.

2] Next, click on the START button, then select SETTINGS then
CONTROL PANEL.

3] When the Control Panel Window pops up, Double Click on FONTS.

4] When the FONTS window pops up, select File then Install New Font...

5] A Add Fonts window will pop up, just go to the folder that you
unzipped the Font(s) to, select the Font(s) and then click on OK.
Now the Font(s) are installed.

  Now you can use the Font(s) in programs that utilize Fonts.  Make
sure that you install the font(s) first, then open up your apps
(so the app will recognize the font).    Sometimes you'll have to
wait until your computer 'auto-refreshes' for programs to recognize
fonts (Windows is sometimes slow to do that).  You can refresh your
computer quicker by going into Windows Explorer -or- My Computer and
press F5 (or in the menubar select VIEW then REFRESH).


__________
DISCLAIMER
����������
-The font(s) in this zip file were created by me (Brian Kent).  All
of my Fonts are Freeware, you can use them any way you want to
(Personal use, Commercial use, or whatever).

-If you have a Font related site and would like to offer my fonts on
your site, go right ahead. All I ask is that you keep this text file
intact with the Font.

-You may not Sell or Distribute my Fonts for profit or alter them in
any way without asking me first.  [e-mail -  kentpw@norwich.net]
