⚠ Add raylib.dll, raylib.lib, and headers into 'lib' and 'include' folders.
Replace placeholder WAV files with real music.
